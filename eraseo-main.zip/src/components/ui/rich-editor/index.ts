export * from './minimal-tiptap';
