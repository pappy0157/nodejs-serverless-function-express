import React from 'react';
import UsersTable from './_components/users-table';

const Page = () => {
  return <UsersTable />;
};

export default Page;
